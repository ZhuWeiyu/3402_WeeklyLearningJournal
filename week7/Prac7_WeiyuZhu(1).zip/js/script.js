function changeWelcomeMessage() {
    document.getElementById('welcome-header').textContent = 'Thank you for visiting!';
}
